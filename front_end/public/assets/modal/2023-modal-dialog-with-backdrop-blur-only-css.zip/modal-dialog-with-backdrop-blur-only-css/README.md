# Modal Dialog with Backdrop Blur [Only CSS]

A Pen created on CodePen.io. Original URL: [https://codepen.io/designfenix/pen/oNpqMdL](https://codepen.io/designfenix/pen/oNpqMdL).

